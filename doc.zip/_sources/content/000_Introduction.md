# Introduction

Welcome to the PKI Lab.


## Objectives

This lab objectives are the following:

- Understand how certificates are issued by a PKI server acting as a Certificate Authority to different components
- Enroll a Fortigate with a PKI to issue Certificaes for the WEB UI and SSL Deep Inspection
- Enroll a typical application server : a Linux Server
- Use manual enrollment 
- Use Automated enrollment with established enrollment protocols 
- Verify how certificate are being used to secure applications




### Lab Components

The different lab components are hosted in a Fabric Studio test environment.

The details to access the different components

| Component | Access | Credentials |
| --------- | ------  | ---------- |
| Fabric Studio | https:// | Credentials: guest/FortinetA123 | 
| Vault PKI | [Vault UI](https://10.222.51.41:28200/) | Credentials: admin/Fortinet@123  |
| Fortigate | https:// | Credentials: admin/fortinet4A!! |
| Windows VM | Connect using RDP (Recommended) at https://<FS URL>:23389 or https:// | Credentials: admin/fortinet |
| Linux Server | on Fabric Studio click on the component and SSH : | Credentials: root/fortinet4A!!|



```{tip}
You need to be logged in the Fabric Sudio to access the different components
````

