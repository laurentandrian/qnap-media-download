# Exercise 2: Automated Certificate Management with EST on Fortigate


Enrollment over Secure Transport (EST) is a protocol defined in RFC 7030 for automating the secure issuance, renewal, and management of X.509 certificates for PKI clients over HTTPS. EST streamlines certificate provisioning by enabling authenticated, encrypted communication between clients (such as web servers or IoT devices) and certificate authorities, reducing manual intervention. It is considered a modern, secure replacement for older protocols like SCEP, supporting advanced cryptographic algorithms and automated workflows



:::{note}
 For this lab The Vault server is already pre-configured with to support the EST protocol
:::