# Exercise 1 : Manual Certificate management with Vault PKI Server 

In this part we are going to 

The PKI server used in the lab is Hashicorp Vault.

Vault is an Enterprise Grade Secrets management platforms. 

Secrets are sensitive, discrete pieces of information like credentials, encryption keys, authentication certificates, and other critical pieces of information your applications need to run consistently and securely.
HCP Vault also supports manual certificates enrollment using CLI or Web UI and automated enrollment using API, ACME, SCEP, EST.

For more Information on Vault: [Vault Documentation](https://developer.hashicorp.com/vault)


## PKI Certificate Authority 

When looking at the best practices to deploy a PKI CA the concept of three-Tier PKI CA is used.

The objective is to ensure Cybersecurity principles of Least Privilege and Separation Of Duties and also provide flexibility of use.


To achieve this objective the root of trust is anchored within an existing company Root CA outside of Vault. So, the Root CA is stored offline, namely outside of Vault.
Then, the Intermediate CA and Issuing CA are stored inside of Vault using a dedicated PKI secret engine for each. Moreover, a dedicated Role is required for issuing  Certificates.

This is described in the figure below:

:::{thumbnail} ../_images/3tier-pki-ca.png
:align: center
:title: E-tier PKI CA
:width: 40%
:::


:::{note}
 For this lab The Vault server is already pre-configured with the 3 functions to issue certificates and also OCSP responder.
:::
### Access Vault Web UI

With a Web browser access the Vault UI (see Introduction for details) and log in.
In Secret Engines, click on PKI and then Roles and click on pkilab.

Look at information displayed :
- Issuer Role
- Max TTL
- Domain Handling
- Key parameters type an size



### Issue a test Certificate

For testing purpose lets issue a certificate:

On the Top of the page click on Generate a Certificate

:::{thumbnail} ../_images/vault-issue-cert.png
:align: center
:title: Generate Cert
:width: 60%
:::


In the next page enter the following

| Field | Content | Comment |
| ----- | ------- | ------- |
|  Common Name | test.pkilab.net | Name of the device | 
| TTL | 30 days | Validity of the Certificate |
| Subject Alternative Name | test.pkilab.net | 

    
:::{thumbnail} ../_images/vault-test-cert.png
:align: center
:title: Generate Test Cert
:width: 60%
:::

Click on Generate.  

You will see the Generate Certificate details.

We have generated a X.509 certificate with:
- Certificate for example for a web server with FQDN test.pkilab.net
- Issue by the CA pkilab.net
- Certificate is valid for 30 days
- It is using an ECC key of 256 bits

:::{note}
using this approach the Private Key is generated and store on Vault PKI server
The private_key is only available once after the certificate is generated, and can be copied.
:::

You can see certificate in the view certificae by copying the PEM on content and use an online decoder : [Certificate Decoder](https://certlogik.com/decoder/)
Paste the content and see the results.

:::{thumbnail} ../_images/test-cert-decoded.png
:align: center
:title: Generate Test Cert
:width: 60%
:::

You can see the full details:

```
Certificate:
    Data:
        Version: 3 (0x2)
        Serial Number:
            09:88:23:fe:d2:36:ca:a0:2d:7e:84:18:cb:e7:c1:9f:25:b0:55:f4
        Signature Algorithm: ecdsa-with-SHA256
        Issuer: CN=pkilab.net
        Validity
            Not Before: Jun  4 15:07:30 2025 GMT
            Not After : Jul  4 15:08:00 2025 GMT
        Subject: CN=test.pkilab.net
        Subject Public Key Info:
            Public Key Algorithm: id-ecPublicKey
                Public-Key: (256 bit)
                pub:
                    04:0e:2a:81:2a:6c:a9:82:71:be:20:ee:cb:4d:c4:
                    e1:6b:68:fd:60:da:a5:37:33:dc:18:9d:d0:f8:bc:
                    cb:c0:00:5c:c2:da:10:fa:e7:ad:a2:69:13:1b:7f:
                    0b:8c:4e:90:7f:51:cb:7d:49:2b:c1:d7:e2:19:4f:
                    18:b6:95:e5:63
                ASN1 OID: prime256v1
                NIST CURVE: P-256
        X509v3 extensions:
            X509v3 Key Usage: critical
                Digital Signature, Key Encipherment, Key Agreement
            X509v3 Extended Key Usage: 
                TLS Web Server Authentication, TLS Web Client Authentication
            X509v3 Subject Key Identifier: 
                85:54:98:66:F8:1E:17:51:37:BC:AC:AB:E9:B3:EE:80:23:36:9F:04
            X509v3 Authority Key Identifier: 
                54:2E:34:61:51:39:F5:DD:EF:68:C0:8E:D5:E1:FE:E2:47:89:49:92
            Authority Information Access: 
                OCSP - URI:https://vault.pkilab.net:8200/v1/pki/ocsp
            X509v3 Subject Alternative Name: 
                DNS:test.pkilab.net
            X509v3 CRL Distribution Points: 
                Full Name:
                  URI:https://vault.pkilab.net:8200/v1/pki/crl
    Signature Algorithm: ecdsa-with-SHA256
    Signature Value:
        30:45:02:20:3a:e3:ec:2d:7d:75:43:ab:56:64:6a:4f:44:21:
        20:c0:4d:69:5d:18:87:e3:27:13:33:ca:94:e7:9e:02:ef:94:
        02:21:00:92:d7:56:18:a2:a2:9c:c6:90:40:2a:0a:e6:83:fa:
        fb:68:6a:c6:c4:23:7e:1e:ec:e8:bc:8b:7a:51:db:da:00

```

With some key information:
- Certificate validity date
- Which CA has signed this certificate
- The key algorithm and size
- The key usage: Digital Signature, Encryption TLS authentication
- OCSP and CRL URLs


In this exercise we have generated the certificate on the Vault server itself, the private key was generated on the server itsef.

However the best practice is to use a Certificate Signing Request (CSR) to request a certificate, where the private key is not generated on a Vault Server.


### Issue Certificates for the Fortigate

In this exercice we are going to cwrtificates for a Fortigate. 

First log into the Windows VM and open Chrome Browser and connect to the Fortigate with https://fgt.pkilab.net

You will see the certificate warning:


:::{thumbnail} ../_images/fgt-cert-warning.png
:align: center
:title: FGT Certificate Warning
:width: 60%
:::

The Fortigate Web UI is using the default GUI server certificate.
Which is a self signed Certificate.
Click on Certificate Details.

:::{thumbnail} ../_images/fgt-cert-details.png
:align: center
:title: FGT Certificate Details
:width: 60%
:::

We can see this Certificate is signed by the Fortigate itself, identified by its serial number.
Click on the Details to more details.

What can you see on the Key Algorithm and The Key lenght ?

This time we are going to generate a CSR on the Fortigate.

On the Certificate Warning page click on Advanced and Proceed to fgt.pkilab.net

#### Fortigate GUI Certificate

Login in the Fortigate.

Go to System/Certificates.

You can view all the Certificates installed on this Fortigate. 
Click on Create/Import on top left and select **Generate CSR**.

The objective is to generate a certificate for the Web GUI.
The FGT FQDN as we have seen before is fgt.pkilab.net
The certificate should use the EC algorith with a key lenght of 256.

:::{thumbnail} ../_images/fgt-cert-details.png
:align: center
:title: FGT CSR
:width: 60%
:::

Then click ok.
In the certificate list you should see now in the Local Certificate the CSR you created with status pending.
Select the certificate and download it on the Windows VM.

The next step is to use Vault to sign the CSR and generate a certificate.

Log into Vault and got to Secrets Engine and then PKI.
in Roles select pkilab and click on Sign Certificate

:::{thumbnail} ../_images/vault-sign-csr.png
:align: center
:title: Vault sign CSR
:width: 60%
:::

On the  Windows VM open the .CSR file with Notepad, you should see the CSR in a PEM encoded format

Copy the entire content in the Vault CSR.
Set the TTL to 30 days.

:::{thumbnail} ../_images/vault-fgt-csr.png
:align: center
:title: Vault Fortigate CSR
:width: 60%
:::


In SANs put fgt.pkilab.net.

Scroll Down and click sign. The CSR ahs been signed and a certificate generated

:::{thumbnail} ../_images/vault-signed-csr.png
:align: center
:title: Vault Signed CSR
:width: 60%
:::


Click on Download the file in a PEM format.

The certificate can now be imported in the Fortigate.

Also in Vault, in Secrets/PKI/Issuers click on the Issuer and Download the CA  certificate in PEM format:

:::{thumbnail} ../_images/vault-ca-cert.png
:align: center
:title: Vault CA Certificate
:width: 60%
:::



Log into the Forigate and go to the Certificates.
Click on import and select the option Import an existing certificate via file upload by clikcin Import Certificate.
Select then Local Certificate and click on Upload file. 

:::{thumbnail} ../_images/fgt-import-cert.png
:align: center
:title: FGT Import Cert
:width: 60%
:::

Click on Create.

You will see now the certificates installed in the FOrtigate.

We can now configure the Fortigate to use this certificate.

Go in System/Settings and on the HTTPS server certificate select the new certificate.

:::{thumbnail} ../_images/fgt-ui-cert.png
:align: center
:title: FGT UI Certificate
:width: 60%
:::

Click on Apply
Close the chrome browser and re-open it.

Browse to the fortigate UI : https://fgt.pkilab.net

We have again the certificate warning, but let's have a look in the details of the certificate.
How is it different from the default Certificate.

Why do we have the security Warning ?

The next step is to install the pkilab.net CA certificate on Windows.

Double click on the CA certificate you downloaded earlier.


:::{thumbnail} ../_images/win-install-ca.png
:align: center
:title: Windows Install CA
:width: 60%
:::

Click on Install Certificate.
Then select Local Machine and Click Next.

In the Certificate Store, select Place the certificate in the FOllowing Store : Trusted Root Certificate Authorities.

:::{thumbnail} ../_images/win-cert-store.png
:align: center
:title: Windows Install CA in Store
:width: 60%
:::

Click Next and then Finish.

Go back to the Google Chrome and reload the windows for the FGT at fgt.pkilab.net

You will noticed that there is no securiy warning or insecure icon.

The connection is secure and the certificate is valid.

#### Fortigate SSL Deep Inspection Certificate

On the Windows VM use Google Chrome to browse to any site on the internet, e.g a news site.

You will see that the connection is not secure with a Certificate Warning.

Why is the connection sot secure ? 

What can you see about the certificate, the Key Algorithm ?


Let's now log into the Fortigate and look at the Firewall Policies.

You will notice a Policy called Internet. 

This policy is appleid to all internet trafffic from the Windows VM and you will notice that SSL inspection is enabled using the default deep-inspection profile.
If we look at this profile:

:::{thumbnail} ../_images/fgt-inspection-profile.png
:align: center
:title: FGT Deep Inspection Profile
:width: 60%
:::

Where the the CA Certificate Fortinet_CA_SSL is used.


Go to System/Certificates and look at the details of the  Fortinet_CA_SSL certificate.

You will notice that the certificate you have seen when browsing the internet is signed by this CA.

When doing SSL deep inspection the Fortigate generates on-the-fly certificate signed by this CA.
They are indeed self signed certificates.

We are now going to use a CA certificate for SSL deep inspection which belongs to our PKI hierachy pkilab.net.
Where the Fortigate becomes an issuing CA.

On the System/Certifcates select Create/Import and then CSR.

Fill with CSR with the information below:

:::{thumbnail} ../_images/fgt-csr-ca.png
:align: center
:title: FGT CSR for CA
:width: 60%
:::

Click on Create.
You will see the Certificate Listed as pending.

Donwload the Certificate on the windows VM.

This time we are not going to issue a certificate but we need to sign the CSR as an intermediate CA.

Log into Vault. Go to Secrets Engines/pki/issuers and click on issuers
Then click on Sign Intermediate.

You will have the Certificate, the Issuing CA and the CA chain.
:::{thumbnail} ../_images/vault-sign-ca.png
:align: center
:title: Vault sign intermediate CA
:width: 60%
:::

Click on OK.

You will have the Certificate, the Issuing CA and the CA chain.
:::{thumbnail} ../_images/win-save-ca.png
:align: center
:title: Save FGT CA Cert
:width: 60%
:::

Saves the files with a .pem extension.

Log in to the Fortigate. In System/Certificates and Import the Certificate

:::{thumbnail} ../_images/fgt-import-ca.png
:align: center
:title: FGT Import CA
:width: 60%
:::


The certificate is now isted in the Local Certificates
We need now to use the certificate in an inspection profile, the default Deep Inspection profile cannot be edited.
Edit the custom SSL Deep inspection Profile to use the certificate imported.

:::{thumbnail} ../_images/fgt-edit-inspection.png
:align: center
:title: Edit Inspection Profile
:width: 60%
:::

Now on the INTERNET Policy change the Inspection profile to the custom profile:

:::{thumbnail} ../_images/fgt-policy-custom.png
:align: center
:title: Edit Inspection Profile
:width: 60%
:::

Click OK.

On Google Chrome browse now to an Internet site

What is the difference ?

The connection is now secure, look at the details of the Certificate.



In this exercise we have seen how to generate certificate manually using the Vault Web UI for a generic device and also for a Fortigate.

In the next exercise we are going to use protocols to simplify and automate the certificate management.



