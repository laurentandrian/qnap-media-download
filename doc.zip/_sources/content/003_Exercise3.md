# Exercise 3: Automated Certificate Management with ACME for App Server


In this exercise we are going to use the ACME protocol to automate the deployment of a certificate on a web application server.

The Automated Certificate Management Environment (ACME) protocol automates the issuance, renewal, and revocation of digital certificates by enabling secure, authenticated communication between certificate authorities (CAs) and web servers over HTTPS using JSON messages. ACME clients, installed on servers, interact with ACME servers at CAs to manage certificates, significantly reducing manual intervention and errors. Originally developed for Let’s Encrypt, ACME is now widely supported and streamlines PKI deployment for secure web services.


:::{note}
 For this lab The Vault server is already pre-configured with to support the ACME protocol.
 The objective of the lab is not to go into the details of ACME configuration on HCP vault.
 For details on ACME on HCP vault see: [ACME and Vault](https://developer.hashicorp.com/vault/tutorials/pki/pki-acme-caddy)
:::


## Access the web application

From the Windows VM browse to this URL: http://app.pkilab.net

You will see a simple web page. 
Obviously this is a non secure connection.

SSH into the AppServer. The Appserver is running the NGINX application to host the web page.
The nginx configuration is located here /etc/nginx/sites-enabled/default

```
server {
    listen 80;
    server_name app.pkilab.net;
    
    location /.well-known/acme-challenge/ {
        root /var/www/acme-challenge;
    }
    
    root /var/www/html;

    index index.html index.htm index.nginx-debian.html;

     location / {
        # First attempt to serve request as file, then
        # as directory, then fall back to displaying a 404.
        try_files $uri $uri/ =404;
    }
}
```

if you are not familiar with nginx we can see the following:
- the server is listening to port 80, not secure web connection
- the root folder for content is in /var/www/html

We are now going to use ACME protocol.

## Use ACME to issue a certificate for the App server

ACME is supported in many different ways to automate certificate management for web application.
For this lab we are going to use Certbot.

[Certbot](https://certbot.eff.org/) used to be Let's Encrypt's official client but is now maintained by the Electronic Frontier Foundation. It is one of the most used ACME clients, supporting issuance, renewal and revocation operations, which are all supported. For more information, refer to the [Certbot Documentation](https://certbot.eff.org/docs/).


:::{note}
 For this lab Certbot is already installed on the app server
 :::


While Certbot can be use do issue a certificate for nginx and also install it we are going to break down the steps

### Use Certbot to issue a certificate

As a first step let's use certbot to issue a certificate for the app server using this command:

```
certbot certonly \
  --server https://vault.pkilab.net:8200/v1/pki/acme/directory \
  -d pkilab.net \
  --key-type ecdsa \
  --cert-name app-server \
  --keep-until-expiring
```

There should be an output like:
```
How would you like to authenticate with the ACME CA?
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
1: Nginx Web Server plugin (nginx)
2: Spin up a temporary webserver (standalone)
3: Place files in webroot directory (webroot)
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
Select the appropriate number [1-3] then [enter] (press 'c' to cancel): 1
Requesting a certificate for app.pkilab.net

Successfully received certificate.
Certificate is saved at: /etc/letsencrypt/live/aoo-server/fullchain.pem
Key is saved at:         /etc/letsencrypt/live/aoo-server/privkey.pem
This certificate expires on 2025-07-06.
These files will be updated when the certificate renews.
Certbot has set up a scheduled task to automatically renew this certificate in the background.
```

Lets look at what happened.

The certbot log file are stored in  /var/log/letsencrypt/letsencrypt.log.

However it is a bit hard to read, you can use a script to decode the conntent to see the ACME flows.
Run the following command:

```
python3 read-acme-logs.py /var/log/letsencrypt/letsencrypt.log
```

You will the formatted content, we can look in details of the different ACME interactions


```
{
    "timestamp": "2025-06-05 07:08:10,904",
    "event": "Sending GET request to https://vault.pkilab.net:8200/v1/pki/acme/directory."
  },
  {
    "timestamp": "2025-06-05 07:08:11,035",
    "event": "Received response:",
    "acme_response": {
      "keyChange": "https://vault.pkilab.net:8200/v1/pki/acme/key-change",
      "meta": {
        "externalAccountRequired": true
      },
      "newAccount": "https://vault.pkilab.net:8200/v1/pki/acme/new-account",
      "newNonce": "https://vault.pkilab.net:8200/v1/pki/acme/new-nonce",
      "newOrder": "https://vault.pkilab.net:8200/v1/pki/acme/new-order",
      "revokeCert": "https://vault.pkilab.net:8200/v1/pki/acme/revoke-cert"
    }
  },

```

Getting a new nonce:
```
  "timestamp": "2025-06-05 07:08:11,055",
    "event": "Sending HEAD request to https://vault.pkilab.net:8200/v1/pki/acme/new-nonce."
  },
  {
    "timestamp": "2025-06-05 07:08:11,063",
    "event": "Received response:",
    "acme_response": "2025-06-05 07:08:11,064:DEBUG:acme.client:Storing nonce: dmF1bHQw492kkhZq6wJBcGUG1NvXdwjJ0daxnHtqueRHe0ut8DOg_HIJujK16A"
  },
  {
    "timestamp": "2025-06-05 07:08:11,064",
    "event": "Storing nonce: dmF1bHQw492kkhZq6wJBcGUG1NvXdwjJ0daxnHtqueRHe0ut8DOg_HIJujK16A"
  },
```


Sending a new order:
```
{
    "timestamp": "2025-06-05 07:08:11,077",
    "event": "Sending POST request to https://vault.pkilab.net:8200/v1/pki/acme/new-order:"
  },
  {
    "timestamp": "2025-06-05 07:08:11,131",
    "event": "Received response:",
    "acme_response": {
      "authorizations": [
        "https://vault.pkilab.net:8200/v1/pki/acme/authorization/1a92c409-11a9-dff1-5c17-dc05f69c9b6a"
      ],
      "expires": "2025-06-06T07:08:11Z",
      "finalize": "https://vault.pkilab.net:8200/v1/pki/acme/order/57eca32e-482f-018e-16ea-f0bfb1494a3a/finalize",
      "identifiers": [
        {
          "type": "dns",
          "value": "app.pkilab.net"
        }
      ],
      "status": "pending"
    }
  },
```


Authorization
```
   "timestamp": "2025-06-05 07:08:11,137",
    "event": "Sending POST request to https://vault.pkilab.net:8200/v1/pki/acme/authorization/1a92c409-11a9-dff1-5c17-dc05f69c9b6a:"
  },
  {
    "timestamp": "2025-06-05 07:08:11,147",
    "event": "Received response:",
    "acme_response": {
      "challenges": [
        {
          "status": "pending",
          "token": "ceKlLQIJY23LPM2o_5FZ2wYZiitM",
          "type": "http-01",
          "url": "https://vault.pkilab.net:8200/v1/pki/acme/challenge/1a92c409-11a9-dff1-5c17-dc05f69c9b6a/http-01"
        },
        {
          "status": "pending",
          "token": "sbqXc-B392SAjccX-g8ix-4l3ada",
          "type": "dns-01",
          "url": "https://vault.pkilab.net:8200/v1/pki/acme/challenge/1a92c409-11a9-dff1-5c17-dc05f69c9b6a/dns-01"
        },
        {
          "status": "pending",
          "token": "xbp8-hri-aTZBDzSBoYxA2h5PHHJ",
          "type": "tls-alpn-01",
          "url": "https://vault.pkilab.net:8200/v1/pki/acme/challenge/1a92c409-11a9-dff1-5c17-dc05f69c9b6a/tls-alpn-01"
        }
      ],
      "identifier": {
        "type": "dns",
        "value": "app.pkilab.net"
      },
      "status": "pending",
      "wildcard": false
    }
```

Challenge:

```
{
    "timestamp": "2025-06-05 07:08:12,326",
    "event": "Sending POST request to https://vault.pkilab.net:8200/v1/pki/acme/challenge/1a92c409-11a9-dff1-5c17-dc05f69c9b6a/http-01:"
  },
  {
    "timestamp": "2025-06-05 07:08:12,352",
    "event": "Received response:",
    "acme_response": {
      "status": "processing",
      "token": "ceKlLQIJY23LPM2o_5FZ2wYZiitM",
      "type": "http-01",
      "url": "https://vault.pkilab.net:8200/v1/pki/acme/challenge/1a92c409-11a9-dff1-5c17-dc05f69c9b6a/http-01"
    }
  },
  ```


HTTP challenge is valid
```
   "event": "Sending POST request to https://vault.pkilab.net:8200/v1/pki/acme/authorization/1a92c409-11a9-dff1-5c17-dc05f69c9b6a:"
  },
  {
    "timestamp": "2025-06-05 07:08:13,372",
    "event": "Received response:",
    "acme_response": {
      "challenges": [
        {
          "status": "valid",
          "token": "ceKlLQIJY23LPM2o_5FZ2wYZiitM",
          "type": "http-01",
          "url": "https://vault.pkilab.net:8200/v1/pki/acme/challenge/1a92c409-11a9-dff1-5c17-dc05f69c9b6a/http-01",
          "validated": "2025-06-05T07:08:12Z"
        },
        {
          "status": "pending",
          "token": "sbqXc-B392SAjccX-g8ix-4l3ada",
          "type": "dns-01",
          "url": "https://vault.pkilab.net:8200/v1/pki/acme/challenge/1a92c409-11a9-dff1-5c17-dc05f69c9b6a/dns-01"
        },
        {
          "status": "pending",
          "token": "xbp8-hri-aTZBDzSBoYxA2h5PHHJ",
          "type": "tls-alpn-01",
          "url": "https://vault.pkilab.net:8200/v1/pki/acme/challenge/1a92c409-11a9-dff1-5c17-dc05f69c9b6a/tls-alpn-01"
        }
      ],
      "expires": "2025-06-20T07:08:12Z",
      "identifier": {
        "type": "dns",
        "value": "app.pkilab.net"
      },
      "status": "valid",
      "wildcard": false
    }
```

Sending the CSR

```
 "timestamp": "2025-06-05 07:08:13,372",
    "event": "Storing nonce: dmF1bHQwMcKq-f_nw25o7pRDeyW6AdXDSzQ2EywTP0aJp0BBbW7Mb3AyZeMR0w",
    "csr": {
      "subject": {},
      "san": [
        "app.pkilab.net"
      ],
      "public_key": "-----BEGIN PUBLIC KEY-----\nMFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEQ5HDXrP9pBX6ySLC7wd4O2EOtr8B\n4Q07BRJsMyX5ClaTV5kUEVq5zmfziPRIJYVYPdvYF22JtF61n+JYnJx/Lw==\n-----END PUBLIC KEY-----\n",
      "extensions": [
        "<SubjectAlternativeName(<GeneralNames([<DNSName(value='app.pkilab.net')>])>)>"
      ]
    }
  },
```


Sending Finalize:
```
   "timestamp": "2025-06-05 07:08:14,865",
    "event": "Sending POST request to https://vault.pkilab.net:8200/v1/pki/acme/order/57eca32e-482f-018e-16ea-f0bfb1494a3a/finalize:"
  },
  {
    "timestamp": "2025-06-05 07:08:14,915",
    "event": "Received response:",
    "acme_response": {
      "authorizations": [
        "https://vault.pkilab.net:8200/v1/pki/acme/authorization/1a92c409-11a9-dff1-5c17-dc05f69c9b6a"
      ],
      "certificate": "https://vault.pkilab.net:8200/v1/pki/acme/order/57eca32e-482f-018e-16ea-f0bfb1494a3a/cert",
      "expires": "2025-06-06T07:08:11Z",
      "finalize": "https://vault.pkilab.net:8200/v1/pki/acme/order/57eca32e-482f-018e-16ea-f0bfb1494a3a/finalize",
      "identifiers": [
        {
          "type": "dns",
          "value": "app.pkilab.net"
        }
      ],
      "status": "valid"
    }
  },
```

Getting the Certificate:
```
 "event": "Sending POST request to https://vault.pkilab.net:8200/v1/pki/acme/order/57eca32e-482f-018e-16ea-f0bfb1494a3a:",
    "certificate": {
      "error": "Unable to load PEM file. See https://cryptography.io/en/latest/faq/#why-can-t-i-import-my-pem-file for more details. MalformedFraming"
    }
  },
  {
    "timestamp": "2025-06-05 07:08:15,936",
    "event": "Received response:",
    "certificate": [
      {
        "subject": {},
        "issuer": {
          "commonName": "pkilab.net"
        },
        "serial_number": "598000626381964017175000181817048818858055821908",
        "not_valid_before": "2025-06-05T07:07:44",
        "not_valid_after": "2025-07-07T07:08:14",
        "san": [
          "app.pkilab.net"
        ],
        "public_key": "-----BEGIN PUBLIC KEY-----\nMFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEQ5HDXrP9pBX6ySLC7wd4O2EOtr8B\n4Q07BRJsMyX5ClaTV5kUEVq5zmfziPRIJYVYPdvYF22JtF61n+JYnJx/Lw==\n-----END PUBLIC KEY-----\n",
        "extensions": [
          "<KeyUsage(digital_signature=True, content_commitment=False, key_encipherment=True, data_encipherment=False, key_agreement=True, key_cert_sign=False, crl_sign=False, encipher_only=False, decipher_only=False)>",
          "<ExtendedKeyUsage([<ObjectIdentifier(oid=1.3.6.1.5.5.7.3.1, name=serverAuth)>])>",
          "<SubjectKeyIdentifier(digest=b'<N\\xe8\\x97\\xe5\\xcc.QTB\\xdbQ\\xcc\\n\\xf8\\x91\\xb1\\xf4-\\xa0')>",
          "<AuthorityKeyIdentifier(key_identifier=b'T.4aQ9\\xf5\\xdd\\xefh\\xc0\\x8e\\xd5\\xe1\\xfe\\xe2G\\x89I\\x92', authority_cert_issuer=None, authority_cert_serial_number=None)>",
          "<AuthorityInformationAccess([<AccessDescription(access_method=<ObjectIdentifier(oid=1.3.6.1.5.5.7.48.1, name=OCSP)>, access_location=<UniformResourceIdentifier(value='https://vault.pkilab.net:8200/v1/pki/ocsp')>)>])>",
          "<SubjectAlternativeName(<GeneralNames([<DNSName(value='app.pkilab.net')>])>)>",
          "<CRLDistributionPoints([<DistributionPoint(full_name=[<UniformResourceIdentifier(value='https://vault.pkilab.net:8200/v1/pki/crl')>], relative_name=None, reasons=None, crl_issuer=None)>])>"
        ]
      }
    ],
    "acme_response": {
      "authorizations": [
        "https://vault.pkilab.net:8200/v1/pki/acme/authorization/1a92c409-11a9-dff1-5c17-dc05f69c9b6a"
      ],
      "certificate": "https://vault.pkilab.net:8200/v1/pki/acme/order/57eca32e-482f-018e-16ea-f0bfb1494a3a/cert",
      "expires": "2025-06-06T07:08:11Z",
      "finalize": "https://vault.pkilab.net:8200/v1/pki/acme/order/57eca32e-482f-018e-16ea-f0bfb1494a3a/finalize",
      "identifiers": [
        {
          "type": "dns",
          "value": "app.pkilab.net"
        }
      ],
      "status": "valid"
    }
  },
  {
    "timestamp": "2025-06-05 07:08:15,936",
    "event": "Storing nonce: dmF1bHQwzJyW0TpoF2ohWwqtxGiAvogE5Vd5gqK8zXTw53LLHFUeFp0GcBcTag",
    "certificate": [
      {
        "subject": {},
        "issuer": {
          "commonName": "pkilab.net"
        },
        "serial_number": "598000626381964017175000181817048818858055821908",
        "not_valid_before": "2025-06-05T07:07:44",
        "not_valid_after": "2025-07-07T07:08:14",
        "san": [
          "app.pkilab.net"
        ],
        "public_key": "-----BEGIN PUBLIC KEY-----\nMFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEQ5HDXrP9pBX6ySLC7wd4O2EOtr8B\n4Q07BRJsMyX5ClaTV5kUEVq5zmfziPRIJYVYPdvYF22JtF61n+JYnJx/Lw==\n-----END PUBLIC KEY-----\n",
        "extensions": [
          "<KeyUsage(digital_signature=True, content_commitment=False, key_encipherment=True, data_encipherment=False, key_agreement=True, key_cert_sign=False, crl_sign=False, encipher_only=False, decipher_only=False)>",
          "<ExtendedKeyUsage([<ObjectIdentifier(oid=1.3.6.1.5.5.7.3.1, name=serverAuth)>])>",
          "<SubjectKeyIdentifier(digest=b'<N\\xe8\\x97\\xe5\\xcc.QTB\\xdbQ\\xcc\\n\\xf8\\x91\\xb1\\xf4-\\xa0')>",
          "<AuthorityKeyIdentifier(key_identifier=b'T.4aQ9\\xf5\\xdd\\xefh\\xc0\\x8e\\xd5\\xe1\\xfe\\xe2G\\x89I\\x92', authority_cert_issuer=None, authority_cert_serial_number=None)>",
          "<AuthorityInformationAccess([<AccessDescription(access_method=<ObjectIdentifier(oid=1.3.6.1.5.5.7.48.1, name=OCSP)>, access_location=<UniformResourceIdentifier(value='https://vault.pkilab.net:8200/v1/pki/ocsp')>)>])>",
          "<SubjectAlternativeName(<GeneralNames([<DNSName(value='app.pkilab.net')>])>)>",
          "<CRLDistributionPoints([<DistributionPoint(full_name=[<UniformResourceIdentifier(value='https://vault.pkilab.net:8200/v1/pki/crl')>], relative_name=None, reasons=None, crl_issuer=None)>])>"
        ]
      },
      {
        "subject": {
          "commonName": "pkilab.net"
        },
        "issuer": {
          "commonName": "pkilab.net"
        },
        "serial_number": "163246863402749617348972641062946957957554016365",
        "not_valid_before": "2025-05-23T08:31:41",
        "not_valid_after": "2026-05-23T08:32:11",
        "san": [
          "pkilab.net"
        ],
        "public_key": "-----BEGIN PUBLIC KEY-----\nMFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEohy8on9mUw7NSuMAPdWks0ca7sQY\nWLMU2r5QUv/eOyXL1maCb/nugO1cYRfVk0MZk9grL47T9yhlXFpHlfV6WA==\n-----END PUBLIC KEY-----\n",
        "extensions": [
          "<KeyUsage(digital_signature=False, content_commitment=False, key_encipherment=False, data_encipherment=False, key_agreement=False, key_cert_sign=True, crl_sign=True, encipher_only=False, decipher_only=False)>",
          "<BasicConstraints(ca=True, path_length=None)>",
          "<SubjectKeyIdentifier(digest=b'T.4aQ9\\xf5\\xdd\\xefh\\xc0\\x8e\\xd5\\xe1\\xfe\\xe2G\\x89I\\x92')>",
          "<AuthorityKeyIdentifier(key_identifier=b'T.4aQ9\\xf5\\xdd\\xefh\\xc0\\x8e\\xd5\\xe1\\xfe\\xe2G\\x89I\\x92', authority_cert_issuer=None, authority_cert_serial_number=None)>",
          "<AuthorityInformationAccess([<AccessDescription(access_method=<ObjectIdentifier(oid=1.3.6.1.5.5.7.48.2, name=caIssuers)>, access_location=<UniformResourceIdentifier(value='http://vault.pkilab.net:8200/v1/pki/ca')>)>])>",
          "<SubjectAlternativeName(<GeneralNames([<DNSName(value='pkilab.net')>])>)>",
          "<CRLDistributionPoints([<DistributionPoint(full_name=[<UniformResourceIdentifier(value='http://vault.pkilab.net:8200/v1/pki/crl')>], relative_name=None, reasons=None, crl_issuer=None)>])>"
        ]
      }
    ]
  },

```



### Installing the Certificate for NGINX

We can now install the certificates for NGINX use 

```
certbot install -v --nginx --cert-name app-server  
  ```

You can now look at the NGINX configuration:
```
cat /etc/nginx/sites-enabled/default
server {
    server_name app.pkilab.net;

    location /.well-known/acme-challenge/ {
        root /var/www/acme-challenge;
    }

    root /var/www/html;

    index index.html index.htm index.nginx-debian.html;

     location / {
        # First attempt to serve request as file, then
        # as directory, then fall back to displaying a 404.
        try_files $uri $uri/ =404;
    }

    listen 443 ssl; # managed by Certbot
    ssl_certificate /etc/letsencrypt/live/aoo-server/fullchain.pem; # managed by Certbot
    ssl_certificate_key /etc/letsencrypt/live/aoo-server/privkey.pem; # managed by Certbot
    include /etc/letsencrypt/options-ssl-nginx.conf; # managed by Certbot
    ssl_dhparam /etc/letsencrypt/ssl-dhparams.pem; # managed by Certbot

}
server {
    if ($host = app.pkilab.net) {
        return 301 https://$host$request_uri;
    } # managed by Certbot


    listen 80;
    server_name app.pkilab.net;
    return 404; # managed by Certbot
```

We see now that certbot have changed the NGINC configuration to enable SSL with the certificated issued by Vault using ACME.


On the Windows machine connect to the application now with https://app.pkilab.net and verify you have now a secure connection.



### Automated Renewal

After executing certbot there was a message with
```
Certbot has set up a scheduled task to automatically renew this certificate in the background.
```

Certbot has installed a linux configuration that monitors the expiration of the certificate and will trigger the automatic renewal.

it can be details using the this linux command:


```
systemctl list-timers
```

```
NEXT                        LEFT        LAST                        PASSED        UNIT                         ACTIVATES
Wed 2025-06-04 23:17:35 UTC 16h left    Wed 2025-06-04 03:10:10 UTC 3h 40min ago  certbot.timer                certbot.service
```





### Useful Certbot commands

List certificate:
```
certbot certificates
Saving debug log to /var/log/letsencrypt/letsencrypt.log

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
Found the following certs:
  Certificate Name: aoo-server
    Serial Number: 30967549f922c8e5e707a513aad5b1b7028ca07d
    Key Type: ECDSA
    Domains: app.pkilab.net
    Expiry Date: 2025-07-07 11:43:43+00:00 (VALID: 31 days)
    Certificate Path: /etc/letsencrypt/live/aoo-server/fullchain.pem
    Private Key Path: /etc/letsencrypt/live/aoo-server/privkey.pem
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

```

Delete a certificate

```
certbot delete --cert-name app-server
``` 


Renew the certificate for testing
```
 certbot renew --cert-name app-server
```

In the lab you may have a message saying the certificate does not need renewal
```
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
Certificate not yet due for renewal

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
The following certificates are not due for renewal yet:
  /etc/letsencrypt/live/aoo-server/fullchain.pem expires on 2025-07-07 (skipped)
No renewals were attempted.
```

Force the renewal:
```
tbot renew --force-renewal --cert-name app-server
```