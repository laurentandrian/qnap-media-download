.. You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to "|project_name|" documentation!
##########################################

.. toctree::
   :maxdepth: 5
   :numbered:
   :caption: Contents

   content/000_Introduction
   content/001_Exercise1
   content/002_Exercise2
   content/003_Exercise3
   
Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
